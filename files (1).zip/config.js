// REZEKI MAKMUR POS - config.js
// Satu-satunya tempat alamat backend. Ganti di sini jika URL deployment berubah.
const APP_URL = 'https://script.google.com/macros/s/AKfycbyAC00fpsWAzrqMpwvvOY9CiO_eFlcJSIv5L7UxrteqyQrJjGAwI_lhmi77S4AVLEuA/exec';

async function kirim(url, opsi) {
  try {
    const r = await fetch(url, opsi);
    return await r.json();
  } catch (e) {
    return { ok: false, pesan: 'Tidak dapat terhubung ke server. Periksa internet Anda lalu coba lagi.' };
  }
}
// POST dengan teks biasa (tanpa header khusus) agar tidak diblokir CORS
function api(aksi, data, token) {
  return kirim(APP_URL, { method: 'POST', body: JSON.stringify({ aksi: aksi, token: token || '', data: data || {} }) });
}
function apiGet(aksi) {
  return kirim(APP_URL + '?aksi=' + encodeURIComponent(aksi));
}
